package com.lockwise.services;

import java.io.IOException;
import java.io.PrintWriter;
import static java.rmi.server.LogStream.log;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name="user_signup", urlPatterns={"/user_signup"})
public class user_signup extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String name = request.getParameter("username");
            String pass = request.getParameter("password");
            String mail = request.getParameter("email");
            log(name+pass+mail);
            try (Connection conn = dbconnect.initializeDatabase()) 
            {
                String query= "INSERT INTO users VALUES (?, ?, ?)" ;
                PreparedStatement stat = conn.prepareStatement(query);
                    stat.setString(1, name);
                    stat.setString(2, mail);
                    stat.setString(3, pass);
                    int result = stat.executeUpdate();
                    if(result > 0)
                    {
                        String msg="regsuccess";
                        String data="";
                        request.setAttribute("msg", data);
                        request.setAttribute("regmsg", msg);
                        RequestDispatcher rd = request.getRequestDispatcher("authenticate_user.jsp"); 
                        rd.forward(request, response); 
                        //request.getRequestDispatcher("authenticate_user.jsp").forward(request, response);
                        //RequestDispatcher rd = getServletContext().getRequestDispatcher("/authenticate_user.jsp");
		        //rd.include(request, response);
                    }
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
