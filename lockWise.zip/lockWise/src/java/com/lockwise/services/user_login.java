package com.lockwise.services;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name="user_login", urlPatterns={"/user_login"})
public class user_login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String name = request.getParameter("usermail");
            String pass = request.getParameter("password"); 
            
           try(Connection conn = dbconnect.initializeDatabase())
           {
            String query= "SELECT * FROM users WHERE email= ? and password= ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setString(1, name);
            stat.setString(2, pass);
            ResultSet result= stat.executeQuery();
            while(result.next())
            {
             userdata.email = result.getString("email");
             userdata.password = result.getString("password");
            }
            log("---?????---"+userdata.email+"---????---"+userdata.password);
             // log("----"+userdata.username+"----"+userdata.password);
            stat.close();
            conn.close();
           }
           if( name.equals(userdata.email) && pass.equals(userdata.password))
            {
            Cookie loginCookie = new Cookie("user",userdata.email);
	    //setting cookie to expiry in 30 mins
	    loginCookie.setMaxAge(30*60);
	    response.addCookie(loginCookie);
            response.sendRedirect("view_dashboard");
            }
          
           else
           {
                String msg="logfailed";
                log("login failed");
                request.setAttribute("msg", msg); 
                log("----"+userdata.username+"----"+userdata.password);
                RequestDispatcher rd = request.getRequestDispatcher("authenticate_user.jsp"); 
                rd.forward(request, response); 
            }
        }
           catch(Exception e)
           {
            System.out.println(e);
           }     
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
