package com.lockwise.services;

public class userdata {
    public static  int id;
    public static String username;
    public static String email;
    public static String password;
    
    public static String fullname;
    public static String mobile;
    public static String address;
    public static String genre;
    public static String gender;
    
    userdata(String u,String v,String w,String x,String y,String z, String a)
{
username = u;
email = v;
fullname = w;
mobile = x;
address = y;
genre = z;
gender = a;
}
}
